A Pen created at CodePen.io. You can find this one at http://codepen.io/k-ivan/pen/pJMLmJ.

 Simple audio player(with playlist) using flexbox, svg, css animations and  js api.

This is an updated version of the player

Old version here http://codepen.io/k-ivan/pen/KMdmeM