A Pen created at CodePen.io. You can find this one at http://codepen.io/alexdevp/pen/RNELPV.

 Inspired by 24hoursofhappy.com