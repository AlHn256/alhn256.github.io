A Pen created at CodePen.io. You can find this one at http://codepen.io/hans/pen/HlrBE.

 Uses one time loading gifs, swaps them in and out for the neat transition. 

Adaptation of this Dribble Shot: http://dribbble.com/shots/1353765-Audio-Player?list=show