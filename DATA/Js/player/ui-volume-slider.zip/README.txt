A Pen created at CodePen.io. You can find this one at http://codepen.io/planetoftheweb/pen/HCLzc.

 This is a working volume slider done with jQuery, jQuery UI, HTML5, JavaScript and CSS. Here's a link to a step by step tutorial on my blog with a YouTube Video. http://bit.ly/Z4Kg1E