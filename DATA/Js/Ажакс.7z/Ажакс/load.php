<?php 
    header("Content-type: application/json");
?>[{
		name: 'Vegetables',
		children: []
	}, {
		name: 'Fruits',
		children: [{
		name: 'Apple',
		children: []
		}, {
		name: 'Orange',
		children: []
		}, {
		name: 'Lemon',
		children: []
		}]
	}, {
		name: 'Candy',
		children: [{
		name: 'Gummies',
		children: []
		}, {
		name: 'Chocolate',
		children: [{
			name: 'M & M\'s',
			children: []
		}, {
			name: 'Hershey Bar',
			children: []
		}]
		}, ]
	}, {
		name: 'Bread',
		children: []
	}]
