A Pen created at CodePen.io. You can find this one at http://codepen.io/enolic/pen/vXABvk.

 search and sort datagrid, ascending and descending with vue 2.0 and lodash